require("dotenv").config();
const express = require("express");
const Database = require("better-sqlite3");
const { nanoid } = require("nanoid");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const puppeteer = require("puppeteer");

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const db = new Database("luckborn.db");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

fs.mkdirSync(path.join(__dirname, "public", "results"), { recursive: true });

db.exec(`
CREATE TABLE IF NOT EXISTS results (
  id TEXT PRIMARY KEY,
  birth_date TEXT NOT NULL,
  score INTEGER NOT NULL,
  money INTEGER NOT NULL,
  love INTEGER NOT NULL,
  career INTEGER NOT NULL,
  opportunity INTEGER NOT NULL,
  lucky_number INTEGER NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

function hashNumber(input, min, max) {
  const h = crypto.createHash("sha256").update(input).digest();
  const n = h.readUInt32BE(0);
  return min + (n % (max - min + 1));
}

function makeResult(birthDate) {
  const seed = `luckborn:${birthDate}`;
  const score = hashNumber(seed + ":score", 55, 99);
  const money = hashNumber(seed + ":money", 50, 99);
  const love = hashNumber(seed + ":love", 50, 99);
  const career = hashNumber(seed + ":career", 50, 99);
  const opportunity = hashNumber(seed + ":opportunity", 50, 99);
  const luckyNumber = hashNumber(seed + ":number", 1, 99);

  let status = "LUCKY";
  if (score >= 90) status = "VERY LUCKY";
  else if (score >= 75) status = "LUCKY";
  else if (score >= 60) status = "GOOD VIBES";
  else status = "KEEP GOING";

  return { score, money, love, career, opportunity, luckyNumber, status };
}

function validateDate(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0,10) === s;
}

let browser;
async function getBrowser() {
  if (!browser) browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox"]
  });
  return browser;
}

async function renderImage(result) {
  const page = await (await getBrowser()).newPage();
  await page.setViewport({ width: 1080, height: 1080, deviceScaleFactor: 1 });
  await page.goto(`${BASE_URL}/card/${result.id}`, { waitUntil: "networkidle0" });
  const file = path.join(__dirname, "public", "results", `${result.id}.png`);
  await page.screenshot({ path: file, type: "png" });
  await page.close();
  return `/results/${result.id}.png`;
}

app.post("/api/result", async (req, res) => {
  try {
    const birthDate = String(req.body.birthDate || "");
    if (!validateDate(birthDate)) {
      return res.status(400).json({ error: "Invalid birth date" });
    }

    const r = makeResult(birthDate);
    const id = nanoid(8);

    db.prepare(`
      INSERT INTO results
      (id,birth_date,score,money,love,career,opportunity,lucky_number,status)
      VALUES (?,?,?,?,?,?,?,?,?)
    `).run(
      id, birthDate, r.score, r.money, r.love, r.career,
      r.opportunity, r.luckyNumber, r.status
    );

    const result = { id, ...r };
    const image = await renderImage(result);

    res.json({
      ...result,
      imageUrl: `${BASE_URL}${image}`,
      shareUrl: `${BASE_URL}/r/${id}`
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Could not generate result" });
  }
});

app.get("/api/result/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM results WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json({
    ...row,
    imageUrl: `${BASE_URL}/results/${row.id}.png`,
    shareUrl: `${BASE_URL}/r/${row.id}`
  });
});

app.get("/r/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM results WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).send("Result not found");

  const image = `${BASE_URL}/results/${row.id}.png`;
  const url = `${BASE_URL}/r/${row.id}`;

  res.send(`<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>My Luck Score is ${row.score}% — LuckBorn</title>
<meta property="og:title" content="My Luck Score is ${row.score}% 🍀">
<meta property="og:description" content="Can you beat my LuckBorn score?">
<meta property="og:image" content="${image}">
<meta property="og:url" content="${url}">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="My Luck Score is ${row.score}%">
<meta name="twitter:image" content="${image}">
<meta http-equiv="refresh" content="0; url=/">
</head>
<body>Opening LuckBorn…</body>
</html>`);
});

app.get("/card/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM results WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).send("Not found");
  res.sendFile(path.join(__dirname, "public", "card.html"));
});

app.get("/api/card-data/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM results WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({error:"Not found"});
  res.json(row);
});

/* Optional Facebook Login starter endpoint.
   Put your Meta app credentials in .env before using it. */
app.get("/auth/facebook", (req, res) => {
  const appId = process.env.META_APP_ID;
  const redirect = process.env.META_REDIRECT_URI;
  if (!appId || !redirect) return res.status(501).send("Facebook Login is not configured.");
  const state = nanoid(24);
  const url =
    "https://www.facebook.com/v23.0/dialog/oauth" +
    `?client_id=${encodeURIComponent(appId)}` +
    `&redirect_uri=${encodeURIComponent(redirect)}` +
    `&state=${encodeURIComponent(state)}` +
    `&scope=public_profile`;
  res.redirect(url);
});

app.get("/auth/facebook/callback", (req, res) => {
  // For production, validate state, exchange the authorization code server-side,
  // verify the returned identity, then create your own application session.
  res.send("Facebook callback received. Configure the server-side code/token exchange before production.");
});

app.listen(PORT, () => {
  console.log(`LuckBorn running at ${BASE_URL}`);
});

process.on("SIGINT", async () => {
  if (browser) await browser.close();
  process.exit(0);
});

# LuckBorn

A small viral-style DOB luck-result web app.

## Features

- DOB input
- Deterministic entertainment result
- SQLite storage
- Unique result URL
- 1080x1080 PNG result generation
- Open Graph image for Facebook link previews
- Facebook share button
- Optional Facebook Login starter route

## Run

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Run:

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Production notes

- Use HTTPS.
- Set `BASE_URL` to the real domain.
- Keep Meta app secrets server-side.
- Implement and verify the OAuth `state` value.
- Exchange the Facebook authorization code on the server and verify the returned identity.
- Create your own secure session; do not expose access tokens to the browser.
- Add rate limiting and bot protection.
- Do not claim the DOB result is scientifically predictive.
- Do not put a user's DOB in a public URL.
